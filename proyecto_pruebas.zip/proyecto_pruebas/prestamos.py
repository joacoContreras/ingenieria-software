"""Aprobación de préstamos — para taller de tabla de decisión."""

UMBRAL_SUELDO = 100000.0


def aprobar_prestamo(cliente_nuevo: bool, sueldo: float, garantia: bool) -> str:
    """Decide la aprobación de un préstamo según las 3 condiciones.

    Tabla de decisión:
        Cliente nuevo + Sueldo > 100K + Garantía  →  APROBADO
        Cliente nuevo + Sueldo > 100K + Sin gar.  →  APROBADO_LIMITADO
        Cliente nuevo + Sueldo ≤ 100K + Garantía  →  APROBADO_LIMITADO
        Cliente nuevo + Sueldo ≤ 100K + Sin gar.  →  RECHAZADO
        Existente + Sueldo > 100K + Garantía       →  APROBADO_PREMIUM
        Existente + Sueldo > 100K + Sin gar.       →  APROBADO
        Existente + Sueldo ≤ 100K + Garantía       →  APROBADO_LIMITADO
        Existente + Sueldo ≤ 100K + Sin gar.       →  RECHAZADO

    Args:
        cliente_nuevo: True si es cliente nuevo, False si existente.
        sueldo: sueldo declarado en la moneda local.
        garantia: True si presenta garantía aceptable.

    Returns:
        "APROBADO_PREMIUM" | "APROBADO" | "APROBADO_LIMITADO" | "RECHAZADO"

    Raises:
        ValueError: si sueldo < 0.
    """
    if sueldo < 0:
        raise ValueError(f"Sueldo no puede ser negativo: {sueldo}")

    sueldo_alto = sueldo > UMBRAL_SUELDO

    if cliente_nuevo:
        if sueldo_alto and garantia:
            return "APROBADO"
        if sueldo_alto and not garantia:
            return "APROBADO_LIMITADO"
        if not sueldo_alto and garantia:
            return "APROBADO_LIMITADO"
        return "RECHAZADO"

    # Cliente existente
    if sueldo_alto and garantia:
        return "APROBADO_PREMIUM"
    if sueldo_alto and not garantia:
        return "APROBADO"
    if not sueldo_alto and garantia:
        return "APROBADO_LIMITADO"
    return "RECHAZADO"
