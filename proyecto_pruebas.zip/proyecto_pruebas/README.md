# Proyecto Pruebas — Caja Negra (Sem 11)

Proyecto base para el taller de pruebas de caja negra. Contiene 3 módulos para aplicar las técnicas vistas en clase.

## Estructura

```
proyecto_pruebas/
├── descuentos.py       — Partición de equivalencia + valores límite
├── prestamos.py        — Tabla de decisión
├── turnos_estado.py    — Transición de estados
├── tests/              — Carpeta donde escriben sus tests
├── pytest.ini
└── README.md
```

## Setup

```bash
pip3 install pytest pytest-cov
```

## Comandos útiles

```bash
# Correr todos los tests
pytest

# Correr solo un archivo de tests
pytest tests/test_prestamos.py -v

# Cobertura
pytest --cov=. --cov-report=term-missing

# Listar tests sin ejecutarlos
pytest --co -q
```

## Verificación rápida

```bash
# Probar que los módulos cargan
python3 -c "from descuentos import calcular_descuento; print(calcular_descuento(50))"
python3 -c "from prestamos import aprobar_prestamo; print(aprobar_prestamo(False, 150000, True))"
python3 -c "from turnos_estado import Turno; t = Turno('DNI','2026-06-10','09:00'); t.confirmar(); print(t.estado)"
```

Si los 3 comandos imprimen un valor (sin error), el proyecto está listo.
