"""Cálculo de descuentos por cantidad — para taller de caja negra."""


def calcular_descuento(cantidad: int) -> float:
    """Calcula el porcentaje de descuento según cantidad comprada.

    Reglas:
        - cantidad <= 0      → ValueError
        - 1 <= cantidad <= 9   → 0% descuento
        - 10 <= cantidad <= 49 → 5% descuento
        - 50 <= cantidad <= 99 → 10% descuento
        - cantidad >= 100      → 15% descuento

    Args:
        cantidad: cantidad de unidades compradas.

    Returns:
        Porcentaje de descuento (0.0, 5.0, 10.0 o 15.0).

    Raises:
        ValueError: si cantidad <= 0.
    """
    if cantidad <= 0:
        raise ValueError(f"Cantidad debe ser positiva, recibido: {cantidad}")
    if cantidad <= 9:
        return 0.0
    if cantidad <= 49:
        return 5.0
    if cantidad <= 99:
        return 10.0
    return 15.0
