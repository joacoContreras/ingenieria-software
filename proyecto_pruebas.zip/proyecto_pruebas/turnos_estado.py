"""Turno médico con estados — para taller de transición de estados."""

from enum import Enum


class EstadoTurno(Enum):
    PROPUESTO = "PROPUESTO"
    CONFIRMADO = "CONFIRMADO"
    ATENDIDO = "ATENDIDO"
    CANCELADO = "CANCELADO"


class InvalidTransitionError(Exception):
    """Lanzada cuando se intenta una transición de estado inválida."""


class Turno:
    """Modelo simple de turno médico con máquina de estados.

    Transiciones válidas:
        PROPUESTO  -> CONFIRMADO  (.confirmar())
        PROPUESTO  -> CANCELADO   (.cancelar())
        CONFIRMADO -> ATENDIDO    (.atender())
        CONFIRMADO -> CANCELADO   (.cancelar())

    Estados terminales: ATENDIDO, CANCELADO.
    Cualquier otra transición lanza InvalidTransitionError.
    """

    def __init__(self, paciente_dni: str, fecha: str, hora: str):
        self.paciente_dni = paciente_dni
        self.fecha = fecha
        self.hora = hora
        self.estado = EstadoTurno.PROPUESTO

    def confirmar(self) -> None:
        """PROPUESTO -> CONFIRMADO."""
        if self.estado != EstadoTurno.PROPUESTO:
            raise InvalidTransitionError(
                f"No se puede confirmar un turno en estado {self.estado.value}"
            )
        self.estado = EstadoTurno.CONFIRMADO

    def atender(self) -> None:
        """CONFIRMADO -> ATENDIDO."""
        if self.estado != EstadoTurno.CONFIRMADO:
            raise InvalidTransitionError(
                f"Solo se puede atender un turno CONFIRMADO. Estado actual: {self.estado.value}"
            )
        self.estado = EstadoTurno.ATENDIDO

    def cancelar(self) -> None:
        """PROPUESTO o CONFIRMADO -> CANCELADO."""
        if self.estado in (EstadoTurno.ATENDIDO, EstadoTurno.CANCELADO):
            raise InvalidTransitionError(
                f"No se puede cancelar un turno en estado terminal: {self.estado.value}"
            )
        self.estado = EstadoTurno.CANCELADO
